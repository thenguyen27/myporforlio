import React from 'react';
import { Project, CarClass } from '../types';

interface ProjectCardProps {
  project: Project;
  theme: string;
}

const getClassColor = (c: CarClass) => {
  switch (c) {
    case 'X': return 'bg-[#00ff00] text-black'; // Green
    case 'S2': return 'bg-[#00aaff] text-white'; // Blue
    case 'S1': return 'bg-[#aa00ff] text-white'; // Purple
    case 'A': return 'bg-[#ff0000] text-white'; // Red
    case 'B': return 'bg-[#ff7f00] text-black'; // Orange
    case 'C': return 'bg-[#ffff00] text-black'; // Yellow
    case 'D': return 'bg-[#808080] text-white'; // Grey
    default: return 'bg-gray-500';
  }
};

const ProjectCard: React.FC<ProjectCardProps> = ({ project, theme }) => {
  const isViceCity = theme === 'vice-city';
  const isClub = theme === 'club';
  const isDeadCells = theme === 'dead-cells';
  const isValorant = theme === 'valorant';
  const isNeon = theme === 'neon-city';

  // NOTE: 'professional' and 'valorant' (Elastic mode) are handled directly in Garage.tsx
  // This component handles the Card-based renderers for Draggable and Marquee modes.

  // --- DEAD CELLS THEME RENDER ---
  if (isDeadCells) {
    // Generate Roman numeral level roughly based on rating
    const level = project.rating > 900 ? 'IX-L' : project.rating > 800 ? 'VII-S' : 'IV';
    const dps = project.rating * 10;
    
    return (
      <div className="group relative w-80 h-[32rem] mx-4 cursor-pointer transition-transform duration-100 hover:scale-105 z-10 font-pixel flex flex-col">
        {/* Item Slot (Icon representation) - Increased size */}
        <div className="relative w-36 h-36 bg-[#222] border-4 border-[#bd6eff] shadow-[0_0_15px_#bd6eff] mb-6 mx-auto hover:scale-110 transition-transform image-pixelated flex-shrink-0">
           <div className="w-full h-full bg-cover bg-center" style={{ backgroundImage: `url(${project.image})`, filter: 'contrast(1.2) brightness(0.8)' }} />
           <div className="absolute bottom-1 right-1 text-[#ffd700] text-[10px] leading-none drop-shadow-md">{level}</div>
        </div>

        {/* Tooltip (The Card) - Fixed layout */}
        <div className="w-full flex-1 flex flex-col bg-[#170c32]/95 border-2 border-[#4d3e75] p-4 text-xs leading-relaxed shadow-[10px_10px_0_rgba(0,0,0,0.5)] relative overflow-hidden">
            {/* Header */}
            <div className="flex justify-between items-center border-b-2 border-[#4d3e75] pb-2 mb-3 flex-shrink-0">
                <span className="text-[#bd6eff] uppercase text-sm tracking-tighter truncate max-w-[60%]">{project.title}</span>
                <div className="text-right flex-shrink-0">
                    <span className="block text-[#ff4d4d] text-base">{dps}</span>
                    <span className="block text-[8px] text-[#888] tracking-widest">PROJECTS/SEC</span>
                </div>
            </div>

            {/* Affixes - Scrollable if content overflows */}
            <div className="space-y-2 mb-2 flex-1 overflow-y-auto pr-1">
                <div className="flex items-start text-[#aaa]">
                    <span className="text-[#ffd700] mr-2">◆</span>
                    <span>+{project.rating}% logic efficiency.</span>
                </div>
                 <div className="flex items-start text-[#aaa]">
                    <span className="text-[#ffd700] mr-2">◆</span>
                    <span>Stack: {project.tech.slice(0, 2).join(', ')}.</span>
                </div>
            </div>

            {/* Flavor Text - Pushed to bottom */}
            <div className="text-[10px] text-[#666] italic text-center mt-auto pt-2 border-t border-[#4d3e75]/30 flex-shrink-0">
                "A weapon of mass construction."
            </div>
        </div>
      </div>
    );
  }

  // --- CLUB THEME (FIFA) RENDER ---
  if (isClub) {
    return (
      <div className="group relative w-72 h-[28rem] mx-4 cursor-pointer transition-transform duration-300 hover:scale-105 hover:-translate-y-2 z-10">
        {/* Holographic Shine Effect on Hover */}
        <div className="absolute inset-0 rounded-[20px_20px_40px_40px] overflow-hidden z-20 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300">
             <div className="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] bg-[linear-gradient(105deg,transparent_20%,rgba(255,255,255,0.4)_25%,transparent_30%)] animate-none group-hover:animate-shine-sweep transform -skew-x-12" />
        </div>

        {/* Card Body */}
        <div className="w-full h-full bg-gradient-to-b from-[#192231] to-[#0e1015] border-2 border-[#d4af37] rounded-[20px_20px_40px_40px] shadow-[0_0_30px_rgba(238,187,84,0.1)] group-hover:shadow-[0_0_50px_rgba(238,187,84,0.4)] text-[#d4af37] overflow-hidden relative flex flex-col">
          
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10 bg-[repeating-linear-gradient(45deg,transparent,transparent_10px,#d4af37_10px,#d4af37_20px)] pointer-events-none" />

          {/* Top Section */}
          <div className="flex h-[60%] p-4 relative z-10">
            {/* Left Info */}
            <div className="flex flex-col items-center w-1/4 pt-2">
                <span className="text-5xl font-display font-bold leading-none text-white">{project.rating > 900 ? 99 : Math.floor(project.rating / 10)}</span>
                <span className="text-2xl font-display font-bold uppercase mt-1">DEV</span>
                <div className="mt-3 flex flex-col gap-2">
                    <div className="w-8 h-5 bg-red-600 rounded-sm shadow-sm" /> {/* Fake Flag */}
                    <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-[#192231] font-bold text-xs">
                        JS
                    </div>
                </div>
            </div>
            
            {/* Player Image (Project Image) */}
            <div className="w-3/4 h-full relative overflow-hidden rounded-tr-[20px] border-l border-b border-[#d4af37]/20">
                <div 
                    className="absolute inset-0 bg-cover bg-center transform group-hover:scale-110 transition-transform duration-500"
                    style={{ backgroundImage: `url(${project.image})` }} 
                />
                {/* Gradient Fade to Blend with Bottom */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#0e1015] opacity-90" />
            </div>
          </div>

          {/* Bottom Section */}
          <div className="h-[40%] bg-gradient-to-b from-[#0e1015]/80 to-black/90 px-4 pb-2 text-center relative z-10">
             <h3 className="text-3xl font-display font-bold uppercase border-b-2 border-[#d4af37]/50 pb-1 mb-3 tracking-widest truncate text-white drop-shadow-md">
                 {project.title}
             </h3>
             
             {/* Stats Grid */}
             <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-lg font-sans">
                 <div className="flex justify-between"><span className="font-bold text-white">99</span> <span className="opacity-80">COD</span></div>
                 <div className="flex justify-between"><span className="font-bold text-white">95</span> <span className="opacity-80">DES</span></div>
                 <div className="flex justify-between"><span className="font-bold text-white">92</span> <span className="opacity-80">LOG</span></div>
                 <div className="flex justify-between"><span className="font-bold text-white">90</span> <span className="opacity-80">SPD</span></div>
             </div>
          </div>
        </div>
      </div>
    );
  }

  // --- NEON CITY (Marquee Item) ---
  if (isNeon) {
      return (
        <div className="group relative w-80 h-[24rem] mx-4 cursor-pointer transform -skew-x-6 hover:skew-x-0 transition-all duration-300">
            <div className="absolute inset-0 bg-black border-2 border-horizon-cyan shadow-[0_0_15px_#00F0FF] group-hover:shadow-[0_0_30px_#00F0FF] transition-shadow">
                <div className="h-40 w-full relative overflow-hidden border-b border-horizon-cyan">
                    <div 
                        className="absolute inset-0 bg-cover bg-center opacity-80 group-hover:scale-110 transition-transform duration-500"
                        style={{ backgroundImage: `url(${project.image})`, filter: 'hue-rotate(180deg) contrast(1.2)' }}
                    />
                    <div className="absolute inset-0 bg-[linear-gradient(0deg,rgba(0,0,0,0)_50%,rgba(0,240,255,0.2)_50%)] bg-[length:100%_4px] pointer-events-none" />
                </div>
                <div className="p-4">
                    <h3 className="text-3xl font-display text-white mb-2">{project.title}</h3>
                    <div className="flex flex-wrap gap-2">
                        {project.tech.map(t => (
                            <span key={t} className="text-xs bg-horizon-cyan/20 text-horizon-cyan border border-horizon-cyan px-2 py-1">{t}</span>
                        ))}
                    </div>
                </div>
                <div className="absolute bottom-2 right-2 text-xs font-mono text-horizon-pink animate-pulse">
                    STATUS: ONLINE
                </div>
            </div>
        </div>
      );
  }

  // --- STANDARD & DRAGGABLE (Festival, Vice City) RENDER ---
  return (
    <div className={`group relative w-72 h-96 md:w-80 md:h-[28rem] flex-shrink-0 cursor-pointer transition-all duration-300 ease-out transform -skew-x-10 hover:skew-x-0 hover:scale-105 hover:z-20 mx-4 rounded-card ${isViceCity ? 'hover:-translate-y-2' : ''}`}>
      
      {/* Shadow/Glow Effect */}
      <div className={`absolute inset-0 transition-all duration-300 rounded-card
        ${isViceCity 
          ? 'bg-black/40 shadow-[0_20px_50px_rgba(0,0,0,0.5)] group-hover:shadow-[0_0_30px_rgba(236,72,153,0.4)]' 
          : 'bg-black/20 shadow-[10px_10px_0px_rgba(0,0,0,0.2)] group-hover:shadow-[0px_0px_30px_rgba(0,240,255,0.6)]'
        }`} 
      />

      {/* Main Card Content */}
      <div className={`absolute inset-0 overflow-hidden transition-colors duration-300 rounded-card
          ${isViceCity 
            ? 'bg-horizon-dark/80 backdrop-blur-md border border-white/10' 
            : 'bg-white border-2 border-transparent group-hover:border-horizon-pink'
          }`}
      >
        
        {/* Image Background */}
        <div 
          className="absolute inset-0 bg-cover bg-center transform scale-125 skew-x-10 group-hover:skew-x-0 transition-transform duration-500 ease-out"
          style={{ backgroundImage: `url(${project.image})` }}
        />
        
        {/* Dark Gradient Overlay */}
        <div className={`absolute inset-0 transition-opacity duration-300 
            ${isViceCity 
              ? 'bg-gradient-to-t from-[#2e1065] via-[#2e1065]/40 to-transparent opacity-60' // Lowered opacity for better image visibility
              : 'bg-gradient-to-t from-black/90 via-black/40 to-transparent opacity-80'
            }`} 
        />

        {/* --- VICE CITY SPECIAL: Mission Passed Overlay --- */}
        {isViceCity && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rotate-[-5deg] z-30 opacity-0 group-hover:opacity-100 transition-all duration-300 scale-50 group-hover:scale-110 pointer-events-none whitespace-nowrap">
            <h2 className="font-display text-4xl text-horizon-yellow uppercase mission-text-shadow">
              Mission Passed
            </h2>
            <div className="text-center font-mono font-bold text-[#4ade80] text-lg bg-black/50 px-2 rounded mt-1">
              +${project.rating * 10} XP
            </div>
          </div>
        )}

        {/* Content Container */}
        <div className="absolute bottom-0 left-0 w-full p-6 transform skew-x-10 group-hover:skew-x-0 transition-transform duration-300">
          
          {/* Metadata Row */}
          <div className="flex items-center justify-between mb-2">
            {!isViceCity ? (
              // Standard Forza Class Badge
              <div className={`px-3 py-0.5 text-2xl font-bold font-display italic ${getClassColor(project.class)} shadow-[2px_2px_0px_rgba(0,0,0,1)]`}>
                {project.class} | {project.rating}
              </div>
            ) : (
              // Vice City Badge
              <div className="flex gap-2">
                 <span className="text-[#4ade80] font-mono font-bold text-sm bg-black/30 px-2 py-1 rounded border border-[#4ade80]/30">
                    $ {project.rating * 150}
                 </span>
              </div>
            )}
          </div>

          {/* Title */}
          <h3 className={`font-display font-bold uppercase leading-none mb-1 drop-shadow-md
             ${isViceCity ? 'text-3xl text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400' : 'text-4xl text-white italic'}`}
          >
            {project.title}
          </h3>
          
          <p className="text-horizon-cyan font-bold tracking-widest text-sm mb-3 uppercase">
            {project.category}
          </p>

          {/* Tech Stack Icons/List */}
          <div className="flex flex-wrap gap-2 mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-75">
            {project.tech.map((t) => (
              <span key={t} className={`text-xs font-semibold px-2 py-1 backdrop-blur-sm
                ${isViceCity 
                   ? 'bg-white/10 text-horizon-pink border border-horizon-pink rounded' 
                   : 'bg-white/20 text-white'}`}
              >
                {t}
              </span>
            ))}
          </div>
          
          {/* Decorative bar */}
          <div className={`h-1 bg-horizon-yellow transition-all duration-500 ease-out 
              ${isViceCity ? 'w-full opacity-50' : 'w-12 group-hover:w-full'}`} 
          />
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;