import React from 'react';
import { EXPERIENCE } from '../constants';
import { Briefcase, GraduationCap } from 'lucide-react';

interface TimelineProps {
  currentTheme?: string;
}

const Timeline: React.FC<TimelineProps> = ({ currentTheme = 'festival' }) => {
  
  const getConfig = () => {
    switch(currentTheme) {
      case 'dead-cells':
        return {
          title: 'RUN HISTORY',
          bg: 'bg-[#110b29]',
          lineColor: 'bg-[#4d3e75]',
          dotColor: 'bg-[#bd6eff]',
          cardBg: 'bg-[#180b2a] border-2 border-[#4d3e75]',
          titleColor: 'text-[#bd6eff]',
          textColor: 'text-gray-400 font-pixel text-xs',
          font: 'font-pixel'
        };
      case 'valorant':
        return {
          title: 'EPISODE HISTORY',
          bg: 'bg-[#0F1923]',
          lineColor: 'bg-white/20',
          dotColor: 'bg-[#FF4655]',
          cardBg: 'bg-[#1a2733] border-l-4 border-[#FF4655]',
          titleColor: 'text-[#ECE8E1]',
          textColor: 'text-[#ECE8E1] font-valo',
          font: 'font-valo tracking-widest'
        };
      case 'club':
        return {
          title: 'SEASON HISTORY',
          bg: 'bg-transparent',
          lineColor: 'bg-[#32ff7e]/30',
          dotColor: 'bg-[#eebb54]',
          cardBg: 'bg-[#141b33]/80 border-b border-[#32ff7e]',
          titleColor: 'text-white',
          textColor: 'text-gray-300 font-sans',
          font: 'font-display'
        };
      case 'vice-city':
        return {
          title: 'PRIORS',
          bg: 'bg-transparent',
          lineColor: 'bg-[#ec4899]',
          dotColor: 'bg-[#fbbf24]',
          cardBg: 'bg-black/40 backdrop-blur-md border border-[#ec4899]',
          titleColor: 'text-[#fbbf24]',
          textColor: 'text-white font-sans',
          font: 'font-display'
        };
      case 'professional':
        return {
          title: 'Experience',
          bg: 'bg-transparent',
          lineColor: 'bg-[#2a2a2a]',
          dotColor: 'bg-[#3b82f6]',
          cardBg: 'bg-[#111] border border-[#2a2a2a] hover:border-[#555] rounded-[16px]',
          titleColor: 'text-white',
          textColor: 'text-[#a1a1aa] font-sans',
          font: 'font-display tracking-tight not-italic'
        };
      default:
        return {
          title: 'CAREER MODE',
          bg: 'bg-white',
          lineColor: 'bg-gray-200',
          dotColor: 'bg-horizon-pink',
          cardBg: 'bg-gray-50',
          titleColor: 'text-horizon-dark',
          textColor: 'text-gray-600 font-sans',
          font: 'font-display italic'
        };
    }
  };

  const config = getConfig();

  return (
    <section className={`py-20 px-6 ${config.bg} relative`} id="timeline">
      <div className="max-w-4xl mx-auto">
        <h2 className={`text-6xl md:text-8xl font-bold uppercase mb-16 text-center ${config.font} ${config.titleColor}`}>
          {config.title}
        </h2>

        <div className="relative">
          {/* Vertical Line */}
          <div className={`absolute left-4 md:left-1/2 transform md:-translate-x-1/2 top-0 h-full w-1 ${config.lineColor}`} />

          <div className="space-y-12">
            {EXPERIENCE.map((exp, index) => {
               const isLeft = index % 2 === 0;
               return (
                 <div key={exp.id} className={`relative flex flex-col md:flex-row items-center ${isLeft ? 'md:flex-row-reverse' : ''}`}>
                    
                    {/* Spacer for Desktop */}
                    <div className="flex-1 hidden md:block" />

                    {/* Dot */}
                    <div className={`absolute left-4 md:left-1/2 transform -translate-x-1/2 w-8 h-8 rounded-full border-4 border-opacity-50 z-10 flex items-center justify-center
                        ${currentTheme === 'dead-cells' ? 'rounded-none rotate-45 border-[#ff2a2a]' : currentTheme === 'professional' ? 'border-[#111] w-4 h-4' : 'border-white'} 
                        ${config.dotColor}`}
                    >
                        {currentTheme !== 'professional' && (exp.type === 'Education' ? <GraduationCap size={14} className="text-white" /> : <Briefcase size={14} className="text-white" />)}
                    </div>

                    {/* Content Card */}
                    <div className={`flex-1 w-full pl-16 md:pl-0 ${isLeft ? 'md:pr-12 md:text-right' : 'md:pl-12 md:text-left'}`}>
                        <div className={`p-6 shadow-lg relative group transition-all hover:-translate-y-1 ${config.cardBg}
                            ${currentTheme === 'club' ? 'rounded-xl' : currentTheme === 'vice-city' ? '-skew-x-2' : currentTheme === 'festival' ? 'skew-x-[-6deg]' : ''}
                        `}>
                            <span className={`inline-block px-3 py-1 text-xs font-bold mb-2 uppercase tracking-widest
                                ${currentTheme === 'club' ? 'bg-[#32ff7e] text-black rounded' : 
                                  currentTheme === 'dead-cells' ? 'text-[#ff2a2a] border border-[#ff2a2a]' : 
                                  currentTheme === 'valorant' ? 'bg-[#FF4655] text-white font-valo' :
                                  currentTheme === 'professional' ? 'bg-[#222] text-[#a1a1aa] border border-[#333] font-mono rounded-[4px]' :
                                  'bg-horizon-dark text-white'}
                            `}>
                                {exp.period}
                            </span>
                            <h3 className={`text-2xl font-bold uppercase mb-1 ${currentTheme === 'festival' ? 'text-horizon-pink' : 'text-white'}`}>
                                {exp.role}
                            </h3>
                            <h4 className="text-lg font-bold opacity-80 mb-4">{exp.company}</h4>
                            <p className={`${config.textColor} leading-relaxed`}>
                                {exp.description}
                            </p>
                        </div>
                    </div>

                 </div>
               );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Timeline;